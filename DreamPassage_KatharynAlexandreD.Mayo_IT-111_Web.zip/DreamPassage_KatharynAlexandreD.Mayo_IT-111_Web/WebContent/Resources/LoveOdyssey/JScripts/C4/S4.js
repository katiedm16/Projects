var ImgCan, ImgCon, ImgBG, Img1, Img2, Img3;
var imgx=0, imgy=0
function LoadImg(){
	ImgCan = document.getElementById('Canvas');
	ImgCon = ImgCan.getContext("2d");
	ImgBG = document.getElementById('BG');
	Img1 = document.getElementById('mc4s4');
	


	
	ImgCon.drawImage(ImgBG,0,0,800,480);
	ImgCon.drawImage(Img1,imgx,imgy,200,300,180,180,200,300);

	


	setInterval("animate()",900);
	// Img1 = document.getElementById('');
	}
	
var cntr=0; var incrx=0;
function animate()
{
cntr++; incrx++;
if (cntr == 4)
	{
	cntr = 0;
	}
imgx = cntr*200;
ImgCon.drawImage(ImgBG,0,0,800,480);
ImgCon.drawImage(Img1,imgx,imgy,200,300,180,180,200,300);





}