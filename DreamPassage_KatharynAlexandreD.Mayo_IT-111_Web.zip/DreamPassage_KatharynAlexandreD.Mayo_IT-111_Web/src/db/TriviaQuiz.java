package db;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.util.Vector;

import org.apache.naming.java.javaURLContextFactory;

public class TriviaQuiz implements Serializable {
	//private java.util.Vector personList; 
	private int QzID;
	private String Question;
	private String Opt1;
	private String Opt2;
	private String Opt3;
	private String Opt4;
	private int ROpt;
	
	public TriviaQuiz(int Input){
		String Database = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
		String sql = "SELECT * FROM quiz WHERE QID=?";
		//String StrySrc = 
		try {
			Class.forName("org.sqlite.JDBC");
			Connection con1 = DriverManager.getConnection(Database);
			PreparedStatement pstmt = con1.prepareStatement(sql);
			pstmt.setInt(1, Input);
			pstmt.execute();
			ResultSet rst = pstmt.executeQuery();
			QzID = rst.getInt(1);
			Question = rst.getString(2);
			Opt1 = rst.getString(3);
			Opt2 = rst.getString(4);
			Opt3 = rst.getString(5);
			Opt4 = rst.getString(6);
			ROpt = rst.getInt(7);
			con1.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public int getID(){
		return QzID;
	}
	public String getQuest(){
		return Question;
	}
	public String getOpt1() {
		return Opt1;
	}
	public String getOpt2() {
		return Opt2;
	}
	public String getOpt3() {
		return Opt3;
	}
	public String getOpt4() {
		return Opt4;
	}
	public int getReal() {
		return ROpt;
	}
}
