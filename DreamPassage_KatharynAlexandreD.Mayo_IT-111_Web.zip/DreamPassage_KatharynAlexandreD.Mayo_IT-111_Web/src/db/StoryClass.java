package db;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.util.Vector;

import org.apache.naming.java.javaURLContextFactory;

public class StoryClass implements Serializable {
	//private java.util.Vector personList; 
	private String ChapTtl;
	private String SceneTtl;
	private String SceneDesc;
	private String SceneScript;
	private String SceneImgs;
	private String Storee;
	private int ChapNo;
	private int SceneNo;
	private int IdentID;
	
	public StoryClass(String StoryCh,int Input){
		String Database = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
		String sql = "SELECT * FROM "+StoryCh+" WHERE storyid=?";
		//String StrySrc = 
		try {
			Class.forName("org.sqlite.JDBC");
			Connection con1 = DriverManager.getConnection(Database);
			PreparedStatement pstmt = con1.prepareStatement(sql);
			pstmt.setInt(1, Input);
			pstmt.execute();
			ResultSet rst = pstmt.executeQuery();
			IdentID = rst.getInt(1);
			ChapNo = rst.getInt(2);
			ChapTtl = rst.getString(3);
			SceneNo = rst.getInt(4);
			SceneTtl = rst.getString(5);
			SceneDesc = rst.getString(6);
			SceneScript = rst.getString(7);
			SceneImgs = rst.getString(8);
			con1.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		Storee = StoryCh;
	}
	public int getID(){
		return IdentID;
	}
	public String getStory(){
		return Storee;
	}
	public int getChapNo() {
		return ChapNo;
	}
	public String getChapTtl() {
		return ChapTtl;
	}
	public int getSceneNo() {
		return SceneNo;
	}
	public String getSceneTtl() {
		return SceneTtl;
	}
	public String getSceneDesc() {
		return SceneDesc;
	}
	public String getSceneScript() {
		return SceneScript;
	}
	public String getSceneImg() {
		return SceneImgs;
	}

}
