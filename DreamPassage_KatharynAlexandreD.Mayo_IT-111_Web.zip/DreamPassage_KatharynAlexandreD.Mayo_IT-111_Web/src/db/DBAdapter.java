package db;

import java.sql.*;

public class DBAdapter {
	public DBAdapter(){
		//alter table document modify column document_id int(4) auto_increment
		try {
			Class.forName("org.sqlite.JDBC");
			String Database = "jdbc:sqlite:WebContent//StevenChaseLemenIT111.sqlite";
			String sql = "INSERT INTO tbstory2 VALUES(null,?,?,?,?,?)";
			Connection con1 = DriverManager.getConnection(Database);
			PreparedStatement pstmt = con1.prepareStatement(sql);
			pstmt.setInt(1, 5); 		
			// Chapter No.
			pstmt.setString(2, "New York, Where Dreams are made of");	
			// Chapter title
			pstmt.setInt(3, 4);		
			// Scene No.
			pstmt.setString(4, "Happy Ending");	
			// Scene title.
			pstmt.setString(5, "Maria then realized that love comes in unexpected ways but at the right time. She may have waited too long but at the end of the day, it is worth the wait. For all good thing comes to those who wait. ");	
			// Scene desc.
			pstmt.execute();
			con1.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static boolean ValidPass(String NAME, String PASS){
		boolean Content = false;
		int RwCnt = 0;
		try {
			Class.forName("org.sqlite.JDBC");
			String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
			String sql = "select * from tbuser";
			Connection con1 = DriverManager.getConnection(url);
			PreparedStatement pstmt = con1.prepareStatement(sql);
			ResultSet rst = pstmt.executeQuery();
			while(rst.next()){
				RwCnt++;
			}
			ResultSet rst2 = pstmt.executeQuery();
			for(int x = 0; x < RwCnt;x++){
				rst2.next();
				if(rst2.getString(4).equals(PASS)){
					if(rst2.getString(2).equals(NAME)){
						Content =true;
						break;
					}
				}
			}
			con1.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Content;
	}
	public static boolean AdminPass(String NAME, String PASS){
		boolean Content = false;
		int RwCnt = 0;
		try {
			Class.forName("org.sqlite.JDBC");
			String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
			String sql = "select * from tbuser";
			Connection con1 = DriverManager.getConnection(url);
			PreparedStatement pstmt = con1.prepareStatement(sql);
			ResultSet rst = pstmt.executeQuery();
			while(rst.next()){
				RwCnt++;
			}
			ResultSet rst2 = pstmt.executeQuery();
			for(int x = 0; x < RwCnt;x++){
				rst2.next();
				if(rst2.getString(4).equals(PASS)){
					if(rst2.getString(2).equals(NAME)){
						if(rst2.getString(3).equalsIgnoreCase("A")){
							Content =true;
							break;
						}
					}
				}
			}
			con1.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Content;
	}
	public static int UIDChk(String NAME, String PASS){
		int content = 0;
    	try{
    		Class.forName("org.sqlite.JDBC");
    		String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
    		String sql = "SELECT * FROM tbuser WHERE username=? AND password=?";
    		Connection con1 = DriverManager.getConnection(url);
    		PreparedStatement pstmt = con1.prepareStatement(sql);
    		pstmt.setString(1, NAME);
    		pstmt.setString(2, PASS);
    		ResultSet rst = pstmt.executeQuery();
    		while (rst.next()){
    			content = rst.getInt(1);
    		}
    		con1.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return content;
	}
	public static String UTypeChk(int UsrID){

		String content = "";
    	try{
    		Class.forName("org.sqlite.JDBC");
    		String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
    		String sql = "SELECT * FROM tbuser WHERE userid=?";
    		Connection con1 = DriverManager.getConnection(url);
    		PreparedStatement pstmt = con1.prepareStatement(sql);
    		pstmt.setInt(1, UsrID);
    		ResultSet rst = pstmt.executeQuery();
    		while (rst.next()){
    			content = rst.getString(3);
    		}
    		con1.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return content;
	}
	
	/*Remove?
	public static String DisplayTriviaQ(){
		String content = "<html><body><div align='center'><form><table border='1'>";
    	try{
    		Class.forName("org.sqlite.JDBC");
    		String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
    		String sql = "select * from quiz";
    		Connection con1 = DriverManager.getConnection(url);
    		PreparedStatement pstmt = con1.prepareStatement(sql);
    		ResultSet rst = pstmt.executeQuery();
    		while (rst.next()){
    			content += "<tr><table border='2'>";
    			content += "<tr><td><b>Question: "+rst.getInt(1);
    			content += "<td><b><div style='width: 150px' >" + rst.getString(2) + "</tr></b></div>";
    			content += "<tr><td><div style='width: 300px' ><input type='radio' name='Q"+rst.getInt(1)+"' value='1' checked='checked'>" + rst.getString(3)+"</div>";
    			content += "<td><div style='width: 300px' ><input type='radio' name='Q"+rst.getInt(1)+"' value='2'>" + rst.getString(4) + "</div></tr>";
    			content += "<tr><td><div style='width: 300px' ><input type='radio' name='Q"+rst.getInt(1)+"' value='3'>" + rst.getString(5)+"</div>";
    			content += "<td><div style='width: 300px' ><input type='radio' name='Q"+rst.getInt(1)+"' value='4'>" + rst.getString(6) + "</div></tr>";
    			content += "</table></tr>";
    		}
    		content += "</table></form></div></body></html>";
    		con1.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return content;
	}
	*/
	
	public static String ChkTriviaQ(int ans){

		String content = "<html><body><div align='center'><form><table border='1'>";
    	try{
    		Class.forName("org.sqlite.JDBC");
    		String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
    		String sql = "select * from quiz";
    		Connection con1 = DriverManager.getConnection(url);
    		PreparedStatement pstmt = con1.prepareStatement(sql);
    		ResultSet rst = pstmt.executeQuery();
    		while (rst.next()){
    			content += "<tr><table border='2'>";
    			content += "<tr><td><b>Question: "+rst.getInt(1);
    			content += "<td><b><div style='width: 150px' >" + rst.getString(2) + "</tr></b></div>";
    			content += "<tr><td><div style='width: 300px' ><input type='radio' name='Q"+rst.getInt(1)+"' value='1' checked='checked'>" + rst.getString(3)+"</div>";
    			content += "<td><div style='width: 300px' ><input type='radio' name='Q"+rst.getInt(1)+"' value='2'>" + rst.getString(4) + "</div></tr>";
    			content += "<tr><td><div style='width: 300px' ><input type='radio' name='Q"+rst.getInt(1)+"' value='3'>" + rst.getString(5)+"</div>";
    			content += "<td><div style='width: 300px' ><input type='radio' name='Q"+rst.getInt(1)+"' value='4'>" + rst.getString(6) + "</div></tr>";
    			content += "</table></tr>";
    		}
    		content += "</table></form></div></body></html>";
    		con1.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return content;
	}
	public static String DisplayAllUsr(){
		String content = "<html><body><table border='1'>";
		content += "<tr><td align='center'> UserID";
		content += "<td align='center'> UserName";
		content += "<td align='center'> UserType";
		content += "<td align='center'> Password";
		content += "<td align='center'> FirstName";
		content += "<td align='center'> LastName";
		content += "<td align='center'> Email";
		content += "<td align='center'> Mobile";
		content += "</tr>";
    	try{
    		Class.forName("org.sqlite.JDBC");
    		String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
    		String sql = "select * from tbuser";
    		Connection con1 = DriverManager.getConnection(url);
    		PreparedStatement pstmt = con1.prepareStatement(sql);
    		ResultSet rst = pstmt.executeQuery();
    		while (rst.next()){
    			content += "<tr><td>" + rst.getInt(1);
    			content += "<td>" + rst.getString(2);
    			content += "<td>" + rst.getString(3);
    			content += "<td>" + rst.getString(4);
    			content += "<td>" + rst.getString(5);
    			content += "<td>" + rst.getString(6);
    			content += "<td>" + rst.getString(7);
    			content += "<td>" + rst.getString(8);
    			content += "</tr>";
    		}
    		content += "</table></body></html>";
    		con1.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return content;
	}
	public static String DisplayAllQuiz(){

		String content = "<html><body><table border='1'>";
		content += "<tr>";
		content += "<td align='center'> Question ID";
		content += "<td align='center'> Question No.";
		content += "<td align='center'> Question";
		content += "<td align='center'> Option 1";
		content += "<td align='center'> Option 2";
		content += "<td align='center'> Option 3";
		content += "<td align='center'> Option 4";
		content += "<td align='center'> Answer";
		content += "</tr>";
    	try{
    		Class.forName("org.sqlite.JDBC");
    		String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
    		String sql = "select * from quiz";
    		Connection con1 = DriverManager.getConnection(url);
    		PreparedStatement pstmt = con1.prepareStatement(sql);
    		ResultSet rst = pstmt.executeQuery();
    		while (rst.next()){
    			content += "<tr><td>" + rst.getInt(1);
    			content += "<td>" + (rst.getRow()-1);
    			content += "<td>" + rst.getString(2);
    			content += "<td>" + rst.getString(3);
    			content += "<td>" + rst.getString(4);
    			content += "<td>" + rst.getString(5);
    			content += "<td>" + rst.getString(6);
    			content += "<td>" + rst.getString(7);
    			content += "</tr>";
    		}
    		content += "</table></body></html>";
    		con1.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return content;
	}
	public static String DisplayGame1Pts(){

		String content = "<html><body><table border='1'>";
		content += "<tr>";
		content += "<td align='center'> Player Name";
		content += "<td align='center'> Time Taken";
		content += "</tr>";
    	try{
    		Class.forName("org.sqlite.JDBC");
    		String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
    		String sql = "select * from G1Pts";
    		Connection con1 = DriverManager.getConnection(url);
    		PreparedStatement pstmt = con1.prepareStatement(sql);
    		ResultSet rst = pstmt.executeQuery();
    		while (rst.next()){
    			content += "<tr><td>" + rst.getString(2);
    			content += "<td>" + rst.getString(3);
    			content += "</tr>";
    		}
    		content += "</table></body></html>";
    		con1.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return content;
	}
	public static String DisplayGame2Pts(){

		String content = "<html><body><table border='1'>";
		content += "<tr>";
		content += "<td align='center'> Player Name";
		content += "<td align='center'> Time Taken";
		content += "</tr>";
    	try{
    		Class.forName("org.sqlite.JDBC");
    		String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
    		String sql = "select * from G2Pts";
    		Connection con1 = DriverManager.getConnection(url);
    		PreparedStatement pstmt = con1.prepareStatement(sql);
    		ResultSet rst = pstmt.executeQuery();
    		while (rst.next()){
    			content += "<tr><td>" + rst.getString(2);
    			content += "<td>" + rst.getString(3);
    			content += "</tr>";
    		}
    		content += "</table></body></html>";
    		con1.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return content;
	}
	public static String DisplayGame3Pts(){

		String content = "<html><body><table border='1'>";
		content += "<tr>";
		content += "<td align='center'> Player Name";
		content += "<td align='center'> Time Taken";
		content += "</tr>";
    	try{
    		Class.forName("org.sqlite.JDBC");
    		String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
    		String sql = "select * from G3Pts";
    		Connection con1 = DriverManager.getConnection(url);
    		PreparedStatement pstmt = con1.prepareStatement(sql);
    		ResultSet rst = pstmt.executeQuery();
    		while (rst.next()){
    			content += "<tr><td>" + rst.getString(2);
    			content += "<td>" + rst.getString(3);
    			content += "</tr>";
    		}
    		content += "</table></body></html>";
    		con1.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return content;
	}
	public static String DisplayQuizPts(){

		String content = "<html><body><table border='1'>";
		content += "<tr>";
		content += "<td align='center'> Player Name";
		content += "<td align='center'> Points";
		content += "</tr>";
    	try{
    		Class.forName("org.sqlite.JDBC");
    		String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
    		String sql = "select * from QzPts";
    		Connection con1 = DriverManager.getConnection(url);
    		PreparedStatement pstmt = con1.prepareStatement(sql);
    		ResultSet rst = pstmt.executeQuery();
    		while (rst.next()){
    			content += "<tr><td>" + rst.getString(2);
    			content += "<td>" + rst.getString(3);
    			content += "</tr>";
    		}
    		content += "</table></body></html>";
    		con1.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return content;
	}
	public static String UAdd(String Usr,String Typ,String Pas, String FNme, String LNme, String Email, String Mob){
		int RwCnt = 0;
		String Content = "";
		try {
			Class.forName("org.sqlite.JDBC");
			String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
			String sql = "select * from tbuser";
			Connection con1 = DriverManager.getConnection(url);
			
			PreparedStatement pstmt = con1.prepareStatement(sql);
			ResultSet rst = pstmt.executeQuery();
			while(rst.next()){
				RwCnt++;
			}
			
			ResultSet rst2 = pstmt.executeQuery();
			for(int x = 0; x < RwCnt;x++){
				rst2.next();
				if(rst2.getString(2).equals(Usr)){
					Content = "-=Username already used=-";
					return Content;
				}
			}
			
			con1.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String Database = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
		String sql = "INSERT INTO tbuser VALUES(null,?,?,?,?,?,?,?)";
		try {
			Class.forName("org.sqlite.JDBC");
			Connection con1 = DriverManager.getConnection(Database);
			PreparedStatement pstmt = con1.prepareStatement(sql);
			pstmt.setString(1, Usr);
			pstmt.setString(2, Typ);
			pstmt.setString(3, Pas);
			pstmt.setString(4, FNme);
			pstmt.setString(5, LNme);
			pstmt.setString(6, Email);
			pstmt.setString(7, Mob);
			pstmt.execute();
			Content = "User Added!";
			con1.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Content;
	}
	public static String QAdd(String Ques,String Op1, String Op2, String Op3, String Op4, int FAns){
		String Database = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
		String sql = "INSERT INTO quiz VALUES(null,?,?,?,?,?,?)";
		String Content = "";
		try {
			Class.forName("org.sqlite.JDBC");
			Connection con1 = DriverManager.getConnection(Database);
			PreparedStatement pstmt = con1.prepareStatement(sql);
			pstmt.setString(1, Ques);
			pstmt.setString(2, Op1);
			pstmt.setString(3, Op2);
			pstmt.setString(4, Op3);
			pstmt.setString(5, Op4);
			pstmt.setInt(6, FAns);
			pstmt.execute();
			Content = "Question Added!";
			con1.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Content;
	}
	public static boolean UCheck(int UsrID){
		boolean Content = false;
		int RwCnt = 0;
		try {
			Class.forName("org.sqlite.JDBC");
			String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
			String sql = "select * from tbuser";
			Connection con1 = DriverManager.getConnection(url);
			
			PreparedStatement pstmt = con1.prepareStatement(sql);
			ResultSet rst = pstmt.executeQuery();
			while(rst.next()){
				RwCnt++;
			}
			
			ResultSet rst2 = pstmt.executeQuery();
			for(int x = 0; x < RwCnt;x++){
				rst2.next();
				if(rst2.getInt(1)== UsrID){
					Content =true;
					break;
				}
			}
			
			con1.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Content;
	}
	public static boolean QCheck(int Ques){
		boolean Content = false;
		int RwCnt = 0;
		try {
			Class.forName("org.sqlite.JDBC");
			String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
			String sql = "select * from quiz";
			Connection con1 = DriverManager.getConnection(url);
			
			PreparedStatement pstmt = con1.prepareStatement(sql);
			ResultSet rst = pstmt.executeQuery();
			while(rst.next()){
				RwCnt++;
			}
			
			ResultSet rst2 = pstmt.executeQuery();
			for(int x = 0; x < RwCnt;x++){
				rst2.next();
				if(rst2.getInt(1) == Ques){
					Content =true;
					break;
				}
			}
			
			con1.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Content;
	}
	public static String USelect(int UsrID){
		String content = "";
		content = "<html><body><table border='1'>";
    	try{
    		Class.forName("org.sqlite.JDBC");
    		String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
    		String sql = "SELECT * FROM tbuser WHERE userid=?";
    		Connection con1 = DriverManager.getConnection(url);
    		PreparedStatement pstmt = con1.prepareStatement(sql);
    		pstmt.setInt(1, UsrID);
    		ResultSet rst = pstmt.executeQuery();
    		while (rst.next()){
    			content += "<tr><td>UserID:" +"<td>"+ rst.getInt(1)+"</tr>";
    			content += "<tr><td>Username:" +"<td>"+ rst.getString(2)+"</tr>";
    			content += "<tr><td>Usertype:" +"<td>"+ rst.getString(3)+"</tr>";
    			content += "<tr><td>Password:" +"<td>"+ rst.getString(4)+"</tr>";
    			content += "<tr><td>First Name:" +"<td>"+ rst.getString(5)+"</tr>";
    			content += "<tr><td>Last Name:" +"<td>"+ rst.getString(6)+"</tr>";
    			content += "<tr><td>Email:" +"<td>"+ rst.getString(7)+"</tr>";
    			content += "<tr><td>Mobile:" +"<td>"+ rst.getString(8)+"</tr>";
    		}
    		content += "</table></body></html>";
    		con1.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return content;
	}
	public static String QSelect(int Ques){
		String content = "";
		content = "<html><body><table border='1'>";
    	try{
    		Class.forName("org.sqlite.JDBC");
    		String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
    		String sql = "SELECT * FROM quiz WHERE QID = ?";
    		Connection con2 = DriverManager.getConnection(url);
    		PreparedStatement pstmt = con2.prepareStatement(sql);
    		pstmt.setInt(1, Ques);
    		ResultSet rst = pstmt.executeQuery();
    		while (rst.next()){
    			content += "<tr><td>QuestionID:" +"<td>"+ rst.getInt(1)+"</tr>";
    			content += "<tr><td>Question:" +"<td>"+ rst.getString(2)+"</tr>";
    			content += "<tr><td>Option1:" +"<td>"+ rst.getString(3)+"</tr>";
    			content += "<tr><td>Option2:" +"<td>"+ rst.getString(4)+"</tr>";
    			content += "<tr><td>Option3:" +"<td>"+ rst.getString(5)+"</tr>";
    			content += "<tr><td>Option4:" +"<td>"+ rst.getString(6)+"</tr>";
    			content += "<tr><td>Real Answer:" +"<td>"+ rst.getString(7)+"</tr>";
    		}
    		content += "</table></body></html>";
    		con2.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return content;
	}
	public static String UKill(int UsrID){
		String content = "";
		try {
			Class.forName("org.sqlite.JDBC");
			String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
			String sql = "DELETE FROM tbuser WHERE userid=?";
			Connection con1 = DriverManager.getConnection(url);
			PreparedStatement pstmt = con1.prepareStatement(sql);
			pstmt.setInt(1, UsrID);
			pstmt.executeUpdate();
			con1.close();
			content = "User Deleted";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return content;
	}
	public static String QKill(int Ques){
		String content = "";
			try {
				Class.forName("org.sqlite.JDBC");
				String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
				String sql = "DELETE FROM quiz WHERE QID=?";
				Connection con1 = DriverManager.getConnection(url);
				PreparedStatement pstmt = con1.prepareStatement(sql);
				pstmt.setInt(1, Ques);
				pstmt.executeUpdate();
				con1.close();
				content = "Question Deleted";
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		return content;
		
	}
	public static String UUpdate(int ID, String Usr,String Typ,String Pas, String FNme, String LNme, String Email, String Mob){
		String content = "";
		try {
			Class.forName("org.sqlite.JDBC");
			String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
			String sql = "UPDATE tbuser SET username=?,type=?,password=?,firstname=?,lastname=?,email=?,mobile=? WHERE userid=?";
			Connection con1 = DriverManager.getConnection(url);
			
			PreparedStatement pstmt = con1.prepareStatement(sql);
			pstmt.setString(1, Usr);
			pstmt.setString(2, Typ);
			pstmt.setString(3, Pas);
			pstmt.setString(4, FNme);
			pstmt.setString(5, LNme);
			pstmt.setString(6, Email);
			pstmt.setString(7, Mob);
			pstmt.setInt(8, ID);
			pstmt.execute();
			content = "User Updated!";
			con1.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return content;
	}
	public static String QUpdate(int ID, String Ques,String Op1, String Op2, String Op3, String Op4, int FAns){
		String content = "";
		try {
			Class.forName("org.sqlite.JDBC");
			String url = "jdbc:sqlite:workspace//StevenChaseLemenIT111//WebContent//StevenChaseLemenIT111.sqlite";
			String sql = "UPDATE quiz SET question=?,select1=?,select2=?,select3=?,select4=?,answer=? WHERE QID=?";
			Connection con1 = DriverManager.getConnection(url);
			
			PreparedStatement pstmt = con1.prepareStatement(sql);
			pstmt.setString(1, Ques);
			pstmt.setString(2, Op1);
			pstmt.setString(3, Op2);
			pstmt.setString(4, Op3);
			pstmt.setString(5, Op4);
			pstmt.setInt(6, FAns);
			pstmt.setInt(7, ID);
			pstmt.execute();
			content = "Question Updated!";
			con1.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return content;
	}
	public static void main(String[] args) {
		//new DBAdapter();
	}

}