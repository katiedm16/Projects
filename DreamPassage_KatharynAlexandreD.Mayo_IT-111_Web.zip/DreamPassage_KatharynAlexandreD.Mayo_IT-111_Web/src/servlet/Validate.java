package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import db.DBAdapter;;

/**
 * Servlet implementation class Validate
 */
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Validate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Vu = request.getParameter("user");
		String Vp =request.getParameter("pass");
		
		String TCheck = DBAdapter.UTypeChk(DBAdapter.UIDChk(Vu, Vp));
		String Confer = "1";
		if(Vu == null || Vp == null)
		{
			RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
			request.setAttribute("msg","--< Please fill out the login informtion >--");
			rd.forward(request,response);
			return;
		}
		else
		{
			boolean Vpass = DBAdapter.ValidPass(Vu, Vp);
			if(Vpass == false){
				RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
				request.setAttribute("msg","--< INVALID LOGIN >--");
				request.setAttribute("user",null);
				request.setAttribute("pass",null);
				rd.forward(request,response);
				return;
			}
			else{
				boolean AdmPass = DBAdapter.AdminPass(Vu, Vp);
				if(AdmPass == true){
					Cookie cookie = new Cookie("cuser",Vu);
					Cookie cookie2 = new Cookie("CUsrTyp",TCheck);
					Cookie cookieConf = new Cookie("CConf",Confer);
					response.addCookie(cookie);
					response.addCookie(cookie2);
					response.addCookie(cookieConf);
					HttpSession session = request.getSession();
					session.setAttribute("Vuser",Vu);
					session.setAttribute("VUsrTyp",TCheck);
					session.setAttribute("NavConf",Confer);
					RequestDispatcher rd = request.getRequestDispatcher("dbmenu.jsp");
					request.setAttribute("Vuser", Vu);
					request.setAttribute("VUsrTyp",TCheck);
					request.setAttribute("NavConf",Confer);
					rd.forward(request,response);
					return;
				}
				Cookie cookie = new Cookie("cuser",Vu);
				Cookie cookie2 = new Cookie("CUsrTyp",TCheck);
				response.addCookie(cookie);
				response.addCookie(cookie2);
				HttpSession session = request.getSession();
				session.setAttribute("Vuser",Vu);
				session.setAttribute("VUsrTyp",TCheck);
				RequestDispatcher rd = request.getRequestDispatcher("MainMenu.jsp");
				request.setAttribute("Vuser", Vu);
				request.setAttribute("VUsrTyp",TCheck);
				rd.forward(request,response);
				return;
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
