package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import db.DBAdapter;

/**
 * Servlet implementation class AddUser
 */
@WebServlet("/AddUser")
public class AddUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<html><style type='text/css'>h1{text-align:center;font-family: monospace;color: DarkBlue;}h2{text-align:center;font-family: monospace;color: DarkBlue;}body {border: thin;border-width: 20px;border-style:groove;border-color: blue;background-color: RoyalBlue;color: white;}</style><body><div align='center'><h1>Add Users</h1>");
		out.println("<br>Fill out the form to add a new User.<br><table border='1'>");
		out.println("<form action='AddUser'>");
		out.println("<tr><td>User Name: <td><input type='text' name='UNme'></tr>");
		out.println("<tr><td>User Type: <td><input type='radio' name='UTyp' value='V'>Visitor<br><input type='radio' name='UTyp' value='A'>Administrator</tr>");
		out.println("<tr><td>Password: <td><input type='password' name='Pass'></tr>");
		out.println("<tr><td>First Name: <td><input type='text' name='FNme'></tr>");
		out.println("<tr><td>Last Name: <td><input type='text' name='LNme'></tr>");
		out.println("<tr><td>Email: <td><input type='text' name='Email'></tr>");
		out.println("<tr><td>Mobile: <td><input type='text' name='Mob'></tr>");
		out.println("</tr></table>");
		out.println("<input type = 'submit' value='Submit' /><br>");
		out.println("</form>");
		out.println("<form action='dbmenu.jsp'>");
		out.println("<input type = 'submit' value='Back' /><br>");
		out.println("</form></div>");
		out.println("</body></html>");
		
		String UsrNme = request.getParameter("UNme");
		String Type =request.getParameter("UTyp");
		String Pass =request.getParameter("Pass");
		String FNme =request.getParameter("FNme");
		String LNme =request.getParameter("LNme");
		String Email =request.getParameter("Email");
		String Mob =request.getParameter("Mob");
		if(UsrNme == null || Type == null || Pass == null || FNme == null || LNme == null || Email == null || Mob == null){
			out.println("<html><body><div align='center'>");
			out.println("You're missing some parts...");
			out.println("</div></body></html>");
		}
		else if(UsrNme.isEmpty() == true || Type.isEmpty() == true  || Pass.isEmpty() == true || FNme.isEmpty() == true || LNme.isEmpty() == true || Email.isEmpty() == true || Mob.isEmpty() == true){
			out.println("<html><body><div align='center'>");
			out.println("You're missing some parts...");
			out.println("</div></body></html>");
		}else{
			out.println("<html><body><div align='center'>");
			out.println(DBAdapter.UAdd(UsrNme,Type,Pass,FNme,LNme,Email,Mob));
			out.println("</div></body></html>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
