package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DBAdapter;

/**
 * Servlet implementation class DeleteQuiz
 */
@WebServlet("/DeleteQuiz")
public class DeleteQuiz extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteQuiz() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<html><style type='text/css'>h1{text-align:center;font-family: monospace;color: DarkBlue;}h2{text-align:center;font-family: monospace;color: DarkBlue;}body {border: thin;border-width: 20px;border-style:groove;border-color: blue;background-color: RoyalBlue;color: white;}</style><body><div align='center'><h1>Delete Quiz Questions</h1>");
		out.println(DBAdapter.DisplayAllQuiz());
		out.println("Type in a question ID to delete.");
		out.println("<form action='DeleteQuiz'>");
		out.println("<input type='text' name='DelQuesV'>");
		out.println("<input type = 'submit' value='Search and Delete' /><br>");
		out.println("</form><br>");
		String SUsr = request.getParameter("DelQuesV");
		if(SUsr == null){
			out.println("Enter Question ID!");
		}
		else if(SUsr.isEmpty()==true){
			out.println("Enter Question ID!");
		}
		else{
			int Qno = Integer.parseInt(SUsr);
			if(DBAdapter.QCheck(Qno)==false){
				out.println("Question does not exist");
			}else{
			out.println("Question Info:");
			out.println(DBAdapter.QSelect(Qno));
			out.println(DBAdapter.QKill(Qno));
		}
		}
		out.println("<form action='dbmenu.jsp'>");
		out.println("<input type = 'submit' value='Back' /><br>");
		out.println("</form></div>");
		out.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
