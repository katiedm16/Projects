package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DBAdapter;

/**
 * Servlet implementation class DispAllQuiz
 */
@WebServlet("/DispAllQuiz")
public class DispAllQuiz extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DispAllQuiz() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<html><style type='text/css'>h1{text-align:center;font-family: monospace;color: DarkBlue;}h2{text-align:center;font-family: monospace;color: DarkBlue;}body {border: thin;border-width: 20px;border-style:groove;border-color: blue;background-color: RoyalBlue;color: white;}</style><body><div align='center'><h1>All Quiz Questions</h1>");
		out.println(DBAdapter.DisplayAllQuiz());
		out.println("<form action='dbmenu.jsp'>");
		out.println("<input type = 'submit' value='Back' /><br>");
		out.println("</form></div>");
		out.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
