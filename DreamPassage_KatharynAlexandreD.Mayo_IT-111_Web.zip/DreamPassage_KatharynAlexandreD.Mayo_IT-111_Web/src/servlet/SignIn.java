package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import db.DBAdapter;

/**
 * Servlet implementation class SignIn
 */
@WebServlet("/SignIn")
public class SignIn extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignIn() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String SIu = request.getParameter("user");
		String SIp =request.getParameter("pass");
		String SICnfrm =request.getParameter("pass2");
		String SIFN =request.getParameter("FN");
		String SILN =request.getParameter("LN");
		String SIEmail =request.getParameter("Emyl");
		String SIMobNo =request.getParameter("mob");
		
		if(SIu == null || SIp == null || SICnfrm == null || SIFN == null || SILN == null || SIEmail == null || SIMobNo == null)
		{
			RequestDispatcher rd = request.getRequestDispatcher("Signup.jsp");
			request.setAttribute("msg","--< Please fill out the Sign-in informtion >--");
			rd.forward(request,response);
			return;
		}
		else if(SIu.isEmpty() == true || SIp.isEmpty() == true || SICnfrm.isEmpty() == true || SIFN.isEmpty() == true || SILN.isEmpty() == true || SIEmail.isEmpty() == true || SIMobNo.isEmpty() == true)
		{
			RequestDispatcher rd = request.getRequestDispatcher("Signup.jsp");
			request.setAttribute("msg","--< Please fill out the Sign-in informtion >--");
			rd.forward(request,response);
			return;
		}
		else
		{
			if(SIp.equals(SICnfrm)){
				DBAdapter.UAdd(SIu,"V", SIp, SIFN, SILN, SIEmail, SIMobNo);
				RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
				request.setAttribute("msg","--< Account Created >--");
				rd.forward(request,response);
				return;
			}
			else
			{
				RequestDispatcher rd = request.getRequestDispatcher("Signup.jsp");
				request.setAttribute("msg","--< Please Confirm Password >--");
				rd.forward(request,response);
				return;
			}
	}}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
