package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DBAdapter;

/**
 * Servlet implementation class AddQuiz
 */
@WebServlet("/AddQuiz")
public class AddQuiz extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddQuiz() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<html><style type='text/css'>h1{text-align:center;font-family: monospace;color: DarkBlue;}h2{text-align:center;font-family: monospace;color: DarkBlue;}body {border: thin;border-width: 20px;border-style:groove;border-color: blue;background-color: RoyalBlue;color: white;}</style><body><div align='center'><h1>Add Quiz Questions</h1>");
		out.println("<br>Type in a question then put in 4 answer options. Real Choice identifies the real answer (1 - 4).<br>");
		out.println("<form action='AddQuiz'><table border='1'>");
		out.println("<tr><td>Question: <td><input type='text' name='Ques' /><br>");
		out.println("<tr><td>Choice 1: <td><input type='text' name='Ans1' /><br>");
		out.println("<tr><td>Choice 2: <td><input type='text' name='Ans2' /><br>");
		out.println("<tr><td>Choice 3: <td><input type='text' name='Ans3' /><br>");
		out.println("<tr><td>Choice 4: <td><input type='text' name='Ans4' /><br>");
		out.println("<tr><td>Real Choice: <td><input type='text' name='FAn' /><br>");
		out.println("</table><input type = 'submit' value='Submit' /><br>");
		out.println("</form>");
		out.println("<form action='dbmenu.jsp'>");
		out.println("<input type = 'submit' value='Back' /><br>");
		out.println("</form></div>");
		out.println("</body></html>");
		
		String Ques = request.getParameter("Ques");
		String A1 =request.getParameter("Ans1");
		String A2 =request.getParameter("Ans2");
		String A3 =request.getParameter("Ans3");
		String A4 =request.getParameter("Ans4");
		String FA =request.getParameter("FAn");
		if(Ques == null || A1 == null || A2 == null || A3 == null || A4 == null || FA == null){
			out.println("<html><body><div align='center'>");
			out.println("You're missing some parts...");
			out.println("</div></body></html>");
		}
		else if(Ques.isEmpty() == true || A1.isEmpty()==true || A2.isEmpty()==true  || A3.isEmpty()==true  || A4.isEmpty()==true || FA.isEmpty()==true){
			out.println("<html><body><div align='center'>");
			out.println("You're missing some parts...");
			out.println("</div></body></html>");
		}else{
			int RButt = Integer.parseInt(FA);
			if(RButt <= 4 && RButt >= 1){
				DBAdapter.QAdd(Ques,A1,A2,A3,A4,RButt);
				out.println("<html><body><div align='center'>");
				out.println("New Question Added!");
				out.println("</div></body></html>");
			}else{
				out.println("<html><body><div align='center'>");
				out.println("Real Choice should be 1 , 2 , 3 or 4");
				out.println("</div></body></html>");
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
