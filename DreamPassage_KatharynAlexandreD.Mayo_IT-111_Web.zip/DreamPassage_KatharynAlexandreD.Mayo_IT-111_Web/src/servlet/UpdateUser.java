package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DBAdapter;

/**
 * Servlet implementation class UpdateUser
 */
@WebServlet("/UpdateUser")
public class UpdateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<html><style type='text/css'>h1{text-align:center;font-family: monospace;color: DarkBlue;}h2{text-align:center;font-family: monospace;color: DarkBlue;}body {border: thin;border-width: 20px;border-style:groove;border-color: blue;background-color: RoyalBlue;color: white;}</style><body><div align='center'><h1>Update Users</h1>");
		out.println(DBAdapter.DisplayAllUsr());
		out.println("<br>Choose a user ID.<br>");
		out.println("<form action='UpdateUser'><table border='1'>");
		out.println("<tr><td>User ID: <td><input type='text' name='UID' /><br>");
		out.println("<tr><td>Username: <td><input type='text' name='UsrN' /><br>");
		out.println("<tr><td>User Type: <td><input type='radio' name='UTyp' value='V'>Visitor<br><input type='radio' name='UTyp' value='A'>Administrator</tr>");
		out.println("<tr><td>Password: <td><input type='text' name='Pass' /><br>");
		out.println("<tr><td>First Name: <td><input type='text' name='FN' /><br>");
		out.println("<tr><td>Last Name: <td><input type='text' name='LN' /><br>");
		out.println("<tr><td>Email: <td><input type='text' name='Eml' /><br>");
		out.println("<tr><td>Mobile: <td><input type='text' name='Mob' /><br>");
		out.println("</table><input type = 'submit' value='Submit' /><br>");
		out.println("</form>");
		out.println("<form action='dbmenu.jsp'>");
		out.println("<input type = 'submit' value='Back' /><br>");
		out.println("</form>");
		out.println("</body></html>");
		
		String UsrID = request.getParameter("UID");
		String UsrNme = request.getParameter("UsrN");
		String UsrTyp = request.getParameter("UTyp");
		String Pass =request.getParameter("Pass");
		String FName =request.getParameter("FN");
		String LName =request.getParameter("LN");
		String Email =request.getParameter("Eml");
		String Mobile =request.getParameter("Mob");
		
		if(UsrID == null || UsrTyp == null  || UsrNme == null || Pass == null || FName == null || LName == null || Email == null || Mobile == null){
			out.println("<html><body><div align='center'>");
			out.println("You're missing some parts...");
			out.println("</div></body></html>");
		}
		else if(UsrID.isEmpty() == true || UsrTyp.isEmpty() == true  || UsrNme.isEmpty() == true || Pass.isEmpty()==true || FName.isEmpty()==true  || LName.isEmpty()==true  || Email.isEmpty()==true || Mobile.isEmpty()==true){
			out.println("<html><body><div align='center'>");
			out.println("You're missing some parts...");
			out.println("</div></body></html>");
		}else{
			int FID = Integer.parseInt(UsrID);
			if(DBAdapter.UCheck(FID)==false){
				out.println("<html><body><div align='center'>");
				out.println("Invalid ID");
				out.println("</div></body></html>");
			}else{
				DBAdapter.UUpdate(FID,UsrNme,UsrTyp,Pass,FName,LName,Email,Mobile);
				out.println("<html><body><div align='center'>");
				out.println("User Updated!");
				out.println("</div></body></html>");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
