package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DBAdapter;

/**
 * Servlet implementation class DeleteUser
 */
@WebServlet("/DeleteUser")
public class DeleteUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<html><style type='text/css'>h1{text-align:center;font-family: monospace;color: DarkBlue;}h2{text-align:center;font-family: monospace;color: DarkBlue;}body {border: thin;border-width: 20px;border-style:groove;border-color: blue;background-color: RoyalBlue;color: white;}</style><body><div align='center'><h1>Delete Users</h1>");
		out.println(DBAdapter.DisplayAllUsr());
		out.println("Type in a User ID to delete.");
		out.println("<form action='DeleteUser'>");
		out.println("<input type='text' name='DelVict'>");
		out.println("<input type = 'submit' value='Search and Delete' /><br>");
		out.println("</form><br>");
		String SUsrID = request.getParameter("DelVict");
		if(SUsrID == null){
			out.println("Enter Username!");
		}
		else if(SUsrID.isEmpty()==true){
			out.println("Enter Username!");
		}
		else {
			int SUsr = Integer.parseInt(SUsrID);
			if(DBAdapter.UCheck(SUsr)==false){
				out.println("User does not exist");
			}else{
				out.println("User Info:");
				out.println(DBAdapter.USelect(SUsr));
				out.println(DBAdapter.UKill(SUsr));
			}
		}
		out.println("<form action='dbmenu.jsp'>");
		out.println("<input type = 'submit' value='Back' /><br>");
		out.println("</form></div>");
		out.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
