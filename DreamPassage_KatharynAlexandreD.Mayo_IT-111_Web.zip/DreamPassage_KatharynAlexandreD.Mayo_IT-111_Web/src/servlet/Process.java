package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import db.StoryClass;

@WebServlet("/Process")
public class Process extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Process() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String StoryChoice = request.getParameter("Q1");
		String NaviDe = request.getParameter("Deci");
		int ServStoryChoice = Integer.parseInt(StoryChoice);
		
		String Stree = "";
		String ToCC = "";
		if(ServStoryChoice >= 1 && ServStoryChoice <= 20){
			Stree = "tbstory";
			ToCC = "ToC.jsp";
		}
		else if(ServStoryChoice >= 21 && ServStoryChoice <= 40){
			Stree = "tbstory1";
			ToCC = "ToC2.jsp";
			ServStoryChoice = (ServStoryChoice - 20);
		}
		else if(ServStoryChoice >= 41 && ServStoryChoice <= 60){
			Stree = "tbstory2";
			ToCC = "ToC3.jsp";
			ServStoryChoice = (ServStoryChoice - 40);
		}
		
		if(NaviDe.equals("NoChoice")){
			NaviDe = "Blank";
		}else if(NaviDe.equals("Sub")){
			ServStoryChoice = ServStoryChoice - 1;
		}else if(NaviDe.equals("Add")){
			ServStoryChoice = ServStoryChoice + 1;
		}
		
		//Javabean
		StoryClass s1 = new StoryClass(Stree,ServStoryChoice);
		//pass info? to the JSP
		HttpSession session = request.getSession();
		session.setAttribute("Story",s1);
		session.setAttribute("TblC",ToCC);
		RequestDispatcher rd = request.getRequestDispatcher("Display.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
